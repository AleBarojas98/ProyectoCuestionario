create table preguntas(pregunta varchar(30), opcion1 varchar(30), opcion2 varchar(30), opcion3 varchar(30), opcion4 varchar(30));
select * from preguntas; 